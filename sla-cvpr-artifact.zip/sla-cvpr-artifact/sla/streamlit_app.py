import streamlit as st
import torch
from PIL import Image
from torchvision import transforms

st.title("SLA Demo — CVPR Artifact")

transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor()
])

q = st.file_uploader("Upload Query Image")
c = st.file_uploader("Upload Candidate Image")

if q and c:
    st.write("Computing SLA score...")
    # Here we simulate SLA score calculation (replace with real model call)
    st.metric("SLA Score", 0.92)
