import torch
import torchvision.models as models

class SLAModel(torch.nn.Module):
    def __init__(self, backbone_name="resnet50", pretrained=True):
        super().__init__()
        if backbone_name == "resnet50":
            self.backbone = models.resnet50(pretrained=pretrained)
            self.backbone = torch.nn.Sequential(*list(self.backbone.children())[:-2])
        else:
            raise NotImplementedError(f"Backbone {backbone_name} not supported")

    def encode(self, x):
        return self.backbone(x)

    def encode_pair(self, x1, x2):
        return self.encode(x1), self.encode(x2)
