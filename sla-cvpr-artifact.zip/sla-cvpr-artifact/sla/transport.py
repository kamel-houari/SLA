import torch

def sinkhorn(cost, eps=0.1, n_iter=20):
    K = torch.exp(-cost / eps)
    u = torch.ones(cost.shape[0], device=cost.device)
    v = torch.ones(cost.shape[1], device=cost.device)

    for _ in range(n_iter):
        u = 1.0 / (K @ v)
        v = 1.0 / (K.t() @ u)

    P = torch.diag(u) @ K @ torch.diag(v)
    return P
