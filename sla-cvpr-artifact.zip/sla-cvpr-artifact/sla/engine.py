import torch

class SLAEngine:
    def __init__(self, model, transport, perturb):
        self.model = model
        self.transport = transport
        self.perturb = perturb

    def compute_agreement(self, img_q, img_c):
        Tq, Tc = self.model.encode_pair(img_q, img_c)
        P = self.transport(Tq, Tc)
        Tq_p = self.perturb(Tq)
        Tc_p = self.perturb(Tc)
        P_p = self.transport(Tq_p, Tc_p)
        return 1 - torch.mean(torch.abs(P - P_p))
