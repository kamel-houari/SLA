# SLA — Stable Latent Agreement Artifact

Official artifact submission for CVPR.

## Requirements

- Python 3.8+
- PyTorch
- Streamlit

## Installation

```bash
pip install -r requirements.txt
